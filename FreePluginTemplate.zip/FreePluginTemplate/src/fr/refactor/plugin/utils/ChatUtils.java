package fr.refactor.plugin.utils;

public class ChatUtils {

   public static String version = "0.0.1";
   public static String name = "FreePluginTemplate";
}
