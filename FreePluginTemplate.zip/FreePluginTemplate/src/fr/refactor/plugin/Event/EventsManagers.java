package fr.refactor.plugin.Event;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

public class EventsManagers {

   /* private Plugin pl;
    public EventsManagers(Plugin pl){
        this.pl = pl;
    }

    public void registerEvents() {
        PluginManager pm = Bukkit.getServer().getPluginManager();
        pm.registerEvents(new Test(), pl);
    } */
}
